'use client';

export function Providers({ children }) {
  return <>{children}</>;
}
